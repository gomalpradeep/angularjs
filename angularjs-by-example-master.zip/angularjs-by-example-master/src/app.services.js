'use strict';
angular.module('app.services', []);

